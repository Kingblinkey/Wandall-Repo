# Wandall Chess Engine (Pure Python 3, zero external dependencies)
import re
import random
import time
import urllib.request
import urllib.parse
import json

UNICODE_PIECES = {
    'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
    'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟',
    '.': '·'
}

PIECE_NAMES = {
    'K': 'White King', 'Q': 'White Queen', 'R': 'White Rook', 'B': 'White Bishop', 'N': 'White Knight', 'P': 'White Pawn',
    'k': 'Black King', 'q': 'Black Queen', 'r': 'Black Rook', 'b': 'Black Bishop', 'n': 'Black Knight', 'p': 'Black Pawn',
    '.': 'Empty'
}

PIECE_VALUES = {
    'P': 100, 'N': 320, 'B': 330, 'R': 500, 'Q': 900, 'K': 20000,
    'p': -100, 'n': -320, 'b': -330, 'r': -500, 'q': -900, 'k': -20000,
    '.': 0
}

# Positional piece tables for basic AI evaluation
PAWN_TABLE = [
    0,  0,  0,  0,  0,  0,  0,  0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
     5,  5, 10, 25, 25, 10,  5,  5,
     0,  0,  0, 20, 20,  0,  0,  0,
     5, -5,-10,  0,  0,-10, -5,  5,
     5, 10, 10,-20,-20, 10, 10,  5,
     0,  0,  0,  0,  0,  0,  0,  0
]

KNIGHT_TABLE = [
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50
]


def square_to_coord(sq):
    file_idx = sq % 8
    rank_idx = 7 - (sq // 8)
    return f"{chr(ord('a') + file_idx)}{rank_idx + 1}"


def coord_to_square(coord):
    if len(coord) < 2:
        return None
    f = ord(coord[0].lower()) - ord('a')
    r = int(coord[1]) - 1
    if 0 <= f <= 7 and 0 <= r <= 7:
        return (7 - r) * 8 + f
    return None


class ChessBoard:
    INITIAL_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    def __init__(self, fen=None):
        self.board = ['.'] * 64
        self.turn = 'w'
        self.castling = {'K': True, 'Q': True, 'k': True, 'q': True}
        self.ep_square = None
        self.halfmove_clock = 0
        self.fullmove_number = 1
        self.move_history = []
        self.set_fen(fen or self.INITIAL_FEN)

    def set_fen(self, fen):
        parts = fen.strip().split()
        rows = parts[0].split('/')
        sq = 0
        for r in rows:
            for char in r:
                if char.isdigit():
                    for _ in range(int(char)):
                        self.board[sq] = '.'
                        sq += 1
                else:
                    self.board[sq] = char
                    sq += 1
        self.turn = parts[1] if len(parts) > 1 else 'w'
        castling_str = parts[2] if len(parts) > 2 else '-'
        self.castling = {
            'K': 'K' in castling_str,
            'Q': 'Q' in castling_str,
            'k': 'k' in castling_str,
            'q': 'q' in castling_str,
        }
        self.ep_square = coord_to_square(parts[3]) if len(parts) > 3 and parts[3] != '-' else None
        self.halfmove_clock = int(parts[4]) if len(parts) > 4 and parts[4].isdigit() else 0
        self.fullmove_number = int(parts[5]) if len(parts) > 5 and parts[5].isdigit() else 1

    def get_fen(self):
        fen_rows = []
        for r in range(8):
            row_str = ""
            empty = 0
            for f in range(8):
                sq = r * 8 + f
                p = self.board[sq]
                if p == '.':
                    empty += 1
                else:
                    if empty > 0:
                        row_str += str(empty)
                        empty = 0
                    row_str += p
            if empty > 0:
                row_str += str(empty)
            fen_rows.append(row_str)

        castling_str = ""
        for k in ['K', 'Q', 'k', 'q']:
            if self.castling.get(k):
                castling_str += k
        if not castling_str:
            castling_str = "-"

        ep_str = square_to_coord(self.ep_square) if self.ep_square is not None else "-"
        return f"{'/'.join(fen_rows)} {self.turn} {castling_str} {ep_str} {self.halfmove_clock} {self.fullmove_number}"

    def is_white_piece(self, sq):
        p = self.board[sq]
        return p != '.' and p.isupper()

    def is_black_piece(self, sq):
        p = self.board[sq]
        return p != '.' and p.islower()

    def get_pseudo_moves(self, color=None):
        color = color or self.turn
        moves = []
        for sq in range(64):
            p = self.board[sq]
            if p == '.':
                continue
            if color == 'w' and not p.isupper():
                continue
            if color == 'b' and not p.islower():
                continue

            ptype = p.upper()
            row, col = sq // 8, sq % 8

            # Pawns
            if ptype == 'P':
                dir_step = -1 if color == 'w' else 1
                start_row = 6 if color == 'w' else 1
                promo_row = 0 if color == 'w' else 7

                # 1 step forward
                fwd_row = row + dir_step
                if 0 <= fwd_row <= 7:
                    fwd_sq = fwd_row * 8 + col
                    if self.board[fwd_sq] == '.':
                        if fwd_row == promo_row:
                            for promo in ['Q', 'R', 'B', 'N']:
                                moves.append((sq, fwd_sq, promo.lower() if color == 'b' else promo))
                        else:
                            moves.append((sq, fwd_sq, None))

                        # 2 steps forward from start
                        if row == start_row:
                            fwd2_sq = (row + 2 * dir_step) * 8 + col
                            if self.board[fwd2_sq] == '.':
                                moves.append((sq, fwd2_sq, None))

                # Diagonal captures
                for d_col in [-1, 1]:
                    cap_col = col + d_col
                    if 0 <= cap_col <= 7 and 0 <= fwd_row <= 7:
                        cap_sq = fwd_row * 8 + cap_col
                        target = self.board[cap_sq]
                        can_capture = (color == 'w' and target.islower()) or (color == 'b' and target.isupper())
                        is_ep = (cap_sq == self.ep_square)
                        if can_capture or is_ep:
                            if fwd_row == promo_row:
                                for promo in ['Q', 'R', 'B', 'N']:
                                    moves.append((sq, cap_sq, promo.lower() if color == 'b' else promo))
                            else:
                                moves.append((sq, cap_sq, None))

            # Knights
            elif ptype == 'N':
                knight_deltas = [(-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)]
                for dr, dc in knight_deltas:
                    nr, nc = row + dr, col + dc
                    if 0 <= nr <= 7 and 0 <= nc <= 7:
                        dest = nr * 8 + nc
                        dest_p = self.board[dest]
                        if dest_p == '.' or (color == 'w' and dest_p.islower()) or (color == 'b' and dest_p.isupper()):
                            moves.append((sq, dest, None))

            # Bishops / Rooks / Queens
            elif ptype in ('B', 'R', 'Q'):
                dirs = []
                if ptype in ('B', 'Q'):
                    dirs.extend([(-1, -1), (-1, 1), (1, -1), (1, 1)])
                if ptype in ('R', 'Q'):
                    dirs.extend([(-1, 0), (1, 0), (0, -1), (0, 1)])

                for dr, dc in dirs:
                    nr, nc = row + dr, col + dc
                    while 0 <= nr <= 7 and 0 <= nc <= 7:
                        dest = nr * 8 + nc
                        dest_p = self.board[dest]
                        if dest_p == '.':
                            moves.append((sq, dest, None))
                        else:
                            if (color == 'w' and dest_p.islower()) or (color == 'b' and dest_p.isupper()):
                                moves.append((sq, dest, None))
                            break
                        nr += dr
                        nc += dc

            # King
            elif ptype == 'K':
                for dr in [-1, 0, 1]:
                    for dc in [-1, 0, 1]:
                        if dr == 0 and dc == 0:
                            continue
                        nr, nc = row + dr, col + dc
                        if 0 <= nr <= 7 and 0 <= nc <= 7:
                            dest = nr * 8 + nc
                            dest_p = self.board[dest]
                            if dest_p == '.' or (color == 'w' and dest_p.islower()) or (color == 'b' and dest_p.isupper()):
                                moves.append((sq, dest, None))

                # Castling
                if color == 'w' and row == 7 and col == 4:
                    if self.castling['K'] and self.board[61] == '.' and self.board[62] == '.' and self.board[63] == 'R':
                        moves.append((60, 62, None))
                    if self.castling['Q'] and self.board[59] == '.' and self.board[58] == '.' and self.board[57] == '.' and self.board[56] == 'R':
                        moves.append((60, 58, None))
                elif color == 'b' and row == 0 and col == 4:
                    if self.castling['k'] and self.board[5] == '.' and self.board[6] == '.' and self.board[7] == 'r':
                        moves.append((4, 6, None))
                    if self.castling['q'] and self.board[3] == '.' and self.board[2] == '.' and self.board[1] == '.' and self.board[0] == 'r':
                        moves.append((4, 2, None))

        return moves

    def find_king(self, color):
        target = 'K' if color == 'w' else 'k'
        for sq in range(64):
            if self.board[sq] == target:
                return sq
        return None

    def is_square_attacked(self, target_sq, by_color):
        opp_moves = self.get_pseudo_moves(color=by_color)
        for _, dest, _ in opp_moves:
            if dest == target_sq:
                return True
        return False

    def is_in_check(self, color):
        king_sq = self.find_king(color)
        if king_sq is None:
            return False
        opp_color = 'b' if color == 'w' else 'w'
        return self.is_square_attacked(king_sq, by_color=opp_color)

    def make_move(self, move):
        src, dst, promo = move
        piece = self.board[src]
        dest_piece = self.board[dst]
        color = 'w' if piece.isupper() else 'b'

        saved_state = {
            'board': list(self.board),
            'turn': self.turn,
            'castling': dict(self.castling),
            'ep_square': self.ep_square,
            'halfmove_clock': self.halfmove_clock,
            'fullmove_number': self.fullmove_number,
        }

        # Handle En Passant capture
        if piece.upper() == 'P' and dst == self.ep_square:
            cap_sq = (src // 8) * 8 + (dst % 8)
            self.board[cap_sq] = '.'

        # Handle Castling rook move
        if piece.upper() == 'K' and abs(src - dst) == 2:
            if dst == 62:  # White O-O
                self.board[61] = 'R'
                self.board[63] = '.'
            elif dst == 58:  # White O-O-O
                self.board[59] = 'R'
                self.board[56] = '.'
            elif dst == 6:  # Black O-O
                self.board[5] = 'r'
                self.board[7] = '.'
            elif dst == 2:  # Black O-O-O
                self.board[3] = 'r'
                self.board[0] = '.'

        # Move the piece
        self.board[dst] = promo if promo else piece
        self.board[src] = '.'

        # Update En Passant square for next turn
        if piece.upper() == 'P' and abs(src - dst) == 16:
            self.ep_square = (src + dst) // 2
        else:
            self.ep_square = None

        # Update castling rights
        if piece == 'K':
            self.castling['K'] = False
            self.castling['Q'] = False
        elif piece == 'k':
            self.castling['k'] = False
            self.castling['q'] = False
        elif piece == 'R':
            if src == 63: self.castling['K'] = False
            elif src == 56: self.castling['Q'] = False
        elif piece == 'r':
            if src == 7: self.castling['k'] = False
            elif src == 0: self.castling['q'] = False

        if dest_piece == 'R':
            if dst == 63: self.castling['K'] = False
            elif dst == 56: self.castling['Q'] = False
        elif dest_piece == 'r':
            if dst == 7: self.castling['k'] = False
            elif dst == 0: self.castling['q'] = False

        if color == 'b':
            self.fullmove_number += 1
        self.turn = 'b' if color == 'w' else 'w'
        return saved_state

    def undo_move(self, saved_state):
        self.board = saved_state['board']
        self.turn = saved_state['turn']
        self.castling = saved_state['castling']
        self.ep_square = saved_state['ep_square']
        self.halfmove_clock = saved_state['halfmove_clock']
        self.fullmove_number = saved_state['fullmove_number']

    def get_legal_moves(self):
        pseudo = self.get_pseudo_moves(self.turn)
        legal = []
        for m in pseudo:
            src, dst, _ = m
            piece = self.board[src]
            # Extra castling check: king cannot castle through check
            if piece.upper() == 'K' and abs(src - dst) == 2:
                if self.is_in_check(self.turn):
                    continue
                step = 1 if dst > src else -1
                if self.is_square_attacked(src + step, by_color='b' if self.turn == 'w' else 'w'):
                    continue

            saved = self.make_move(m)
            # Cannot leave own king in check
            opp_color = self.turn  # turn switched in make_move
            own_color = 'b' if opp_color == 'w' else 'w'
            if not self.is_in_check(own_color):
                legal.append(m)
            self.undo_move(saved)
        return legal

    def is_game_over(self):
        legal = self.get_legal_moves()
        if not legal:
            if self.is_in_check(self.turn):
                winner = 'Black' if self.turn == 'w' else 'White'
                return True, f"Checkmate! {winner} wins."
            return True, "Draw by Stalemate."
        return False, ""

    def uci_to_move(self, uci):
        uci = uci.strip().lower()
        if len(uci) < 4:
            return None
        src = coord_to_square(uci[:2])
        dst = coord_to_square(uci[2:4])
        promo = uci[4].upper() if len(uci) > 4 else None
        if src is None or dst is None:
            return None
        for m in self.get_legal_moves():
            if m[0] == src and m[1] == dst:
                if promo:
                    if m[2] and m[2].upper() == promo:
                        return m
                else:
                    return m
        return None

    def move_to_uci(self, move):
        src, dst, promo = move
        res = f"{square_to_coord(src)}{square_to_coord(dst)}"
        if promo:
            res += promo.lower()
        return res

    def evaluate(self):
        score = 0
        for sq in range(64):
            p = self.board[sq]
            if p == '.':
                continue
            val = PIECE_VALUES.get(p, 0)
            score += val
            # Positional score for pawns/knights
            if p == 'P':
                score += PAWN_TABLE[sq]
            elif p == 'p':
                score -= PAWN_TABLE[63 - sq]
            elif p == 'N':
                score += KNIGHT_TABLE[sq]
            elif p == 'n':
                score -= KNIGHT_TABLE[63 - sq]
        return score

    def get_best_move(self, depth=2):
        legal = self.get_legal_moves()
        if not legal:
            return None
        is_max = (self.turn == 'w')

        def minimax(d, alpha, beta, maximizing):
            over, _ = self.is_game_over()
            if d == 0 or over:
                return self.evaluate()

            moves = self.get_legal_moves()
            if maximizing:
                max_eval = -999999
                for mv in moves:
                    saved = self.make_move(mv)
                    ev = minimax(d - 1, alpha, beta, False)
                    self.undo_move(saved)
                    max_eval = max(max_eval, ev)
                    alpha = max(alpha, ev)
                    if beta <= alpha:
                        break
                return max_eval
            else:
                min_eval = 999999
                for mv in moves:
                    saved = self.make_move(mv)
                    ev = minimax(d - 1, alpha, beta, True)
                    self.undo_move(saved)
                    min_eval = min(min_eval, ev)
                    beta = min(beta, ev)
                    if beta <= alpha:
                        break
                return min_eval

        best_move = None
        if is_max:
            best_val = -999999
            for mv in legal:
                saved = self.make_move(mv)
                val = minimax(depth - 1, -999999, 999999, False)
                self.undo_move(saved)
                if val > best_val:
                    best_val = val
                    best_move = mv
        else:
            best_val = 999999
            for mv in legal:
                saved = self.make_move(mv)
                val = minimax(depth - 1, -999999, 999999, True)
                self.undo_move(saved)
                if val < best_val:
                    best_val = val
                    best_move = mv

        return best_move or random.choice(legal)


# --- Online Lichess Client Wrapper ---

class LichessClient:
    BASE_URL = "https://lichess.org"

    def __init__(self, token=None):
        self.token = (token or "").strip()

    def _headers(self):
        h = {'User-Agent': 'Wandall-IPTV-Chess/1.5.0'}
        if self.token:
            h['Authorization'] = f'Bearer {self.token}'
        return h

    def create_ai_challenge(self, level=1, color='random'):
        url = f"{self.BASE_URL}/api/challenge/ai"
        data = urllib.parse.urlencode({'level': level, 'color': color}).encode('utf-8')
        req = urllib.request.Request(url, data=data, headers=self._headers())
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8'))

    def get_game_state(self, game_id):
        url = f"{self.BASE_URL}/api/board/game/stream/{game_id}"
        req = urllib.request.Request(url, headers=self._headers())
        with urllib.request.urlopen(req, timeout=10) as resp:
            line = resp.readline().decode('utf-8')
            return json.loads(line) if line else None

    def make_move(self, game_id, uci_move):
        url = f"{self.BASE_URL}/api/board/game/{game_id}/move/{uci_move}"
        req = urllib.request.Request(url, data=b'', headers=self._headers())
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8'))


# --- Wandall Room Code Relay Wrapper ---

class WandallRoomRelay:
    """
    Zero-config public JSON relay for 4-digit room matches between Wandall users.
    Uses free REST API endpoints to exchange FEN and move history.
    """
    RELAY_API = "https://api.restful-api.dev/objects"

    @classmethod
    def create_room(cls, host_name="Host"):
        room_code = str(random.randint(1000, 9999))
        payload = json.dumps({
            "name": f"WandallChess_{room_code}",
            "data": {
                "room_code": room_code,
                "host": host_name,
                "guest": "",
                "fen": ChessBoard.INITIAL_FEN,
                "moves": [],
                "turn": "w",
                "status": "waiting",
                "last_active": time.time()
            }
        }).encode('utf-8')
        req = urllib.request.Request(cls.RELAY_API, data=payload, headers={'Content-Type': 'application/json', 'User-Agent': 'WandallIPTV'})
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                obj = json.loads(resp.read().decode('utf-8'))
                return room_code, obj.get('id')
        except Exception:
            return room_code, f"local_{room_code}"

    @classmethod
    def get_room(cls, object_id):
        if str(object_id).startswith("local_"):
            return None
        url = f"{cls.RELAY_API}/{object_id}"
        req = urllib.request.Request(url, headers={'User-Agent': 'WandallIPTV'})
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception:
            return None

    @classmethod
    def send_move(cls, object_id, room_code, new_fen, uci_move, player_name):
        if str(object_id).startswith("local_"):
            return True
        url = f"{cls.RELAY_API}/{object_id}"
        payload = json.dumps({
            "name": f"WandallChess_{room_code}",
            "data": {
                "room_code": room_code,
                "fen": new_fen,
                "last_move": uci_move,
                "last_player": player_name,
                "last_active": time.time()
            }
        }).encode('utf-8')
        req = urllib.request.Request(url, data=payload, headers={'Content-Type': 'application/json', 'User-Agent': 'WandallIPTV'}, method='PUT')
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                return True
        except Exception:
            return False
