import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
FAV_FILE = 'favorites.json'
PROGRESS_FILE = 'progress.json'
HISTORY_FILE = 'history.json'
INDEX_FILE = 'search_index.json'
CACHE_DIR = 'cache'


def _ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def _file_path(name):
    _ensure_profile()
    return os.path.join(PROFILE, name)


def _read_json(name, default):
    path = _file_path(name)
    if not xbmcvfs.exists(path):
        return default
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        return json.loads(raw) if raw else default
    except Exception as exc:
        xbmc.log(f'[Wandall] read {name}: {exc}', xbmc.LOGERROR)
        return default


def _write_json(name, data):
    path = _file_path(name)
    payload = json.dumps(data, ensure_ascii=False)
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(payload)
    finally:
        handle.close()


def load_favorites():
    data = _read_json(FAV_FILE, {'items': []})
    items = data.get('items') if isinstance(data, dict) else []
    return items if isinstance(items, list) else []


def save_favorites(items):
    _write_json(FAV_FILE, {'items': items})


def fav_key(kind, item_id):
    return f'{kind}:{item_id}'


def is_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    return any(item.get('key') == key for item in load_favorites())


def add_favorite(item):
    items = [entry for entry in load_favorites() if entry.get('key') != item.get('key')]
    items.insert(0, item)
    save_favorites(items)


def remove_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    save_favorites([item for item in load_favorites() if item.get('key') != key])


# --- Progress & Continue Watching ---

def load_progress():
    data = _read_json(PROGRESS_FILE, {})
    return data if isinstance(data, dict) else {}


def get_progress(key):
    return load_progress().get(key)


def set_progress(key, position, total, **meta):
    if not key:
        return
    data = load_progress()
    if total and position >= max(total * 0.92, total - 30):
        data.pop(key, None)
    elif position > 10:
        entry = data.get(key) or {}
        entry.update(meta)
        entry['position'] = float(position)
        entry['total'] = float(total or 0)
        entry['updated'] = time.time()
        data[key] = entry
    else:
        return
    _write_json(PROGRESS_FILE, data)


def remove_progress(key):
    data = load_progress()
    if key in data:
        data.pop(key, None)
        _write_json(PROGRESS_FILE, data)


def clear_progress():
    _write_json(PROGRESS_FILE, {})


def continue_watching():
    items = []
    for key, value in load_progress().items():
        if not isinstance(value, dict):
            continue
        if value.get('position', 0) > 10:
            items.append((key, value))
    items.sort(key=lambda pair: pair[1].get('updated', 0), reverse=True)
    return items[:50]


# --- Watch History Storage ---

def load_history():
    data = _read_json(HISTORY_FILE, {'items': []})
    items = data.get('items') if isinstance(data, dict) else []
    return items if isinstance(items, list) else []


def save_history(items):
    _write_json(HISTORY_FILE, {'items': items[:250]})


def add_history(item):
    if not item or not item.get('key'):
        return
    items = [entry for entry in load_history() if entry.get('key') != item.get('key')]
    items.insert(0, item)
    save_history(items)


def remove_history(key):
    items = [item for item in load_history() if item.get('key') != key]
    save_history(items)


def clear_history(kind=None):
    if not kind or kind == 'all':
        save_history([])
        return
    kinds_to_remove = {
        'movie': {'movie', 'vod'},
        'series': {'series', 'episode'},
        'live': {'live', 'm3u'},
    }.get(kind, {kind})
    items = [item for item in load_history() if item.get('kind') not in kinds_to_remove]
    save_history(items)


def get_history(kind=None):
    items = load_history()
    if not kind or kind == 'all':
        return items
    kinds_to_filter = {
        'movie': {'movie', 'vod'},
        'series': {'series', 'episode'},
        'live': {'live', 'm3u'},
    }.get(kind, {kind})
    return [item for item in items if item.get('kind') in kinds_to_filter]


# --- Fast Compact Search Index ---

def get_any_id(it):
    if not isinstance(it, dict):
        return None
    for k in ('series_id', 'stream_id', 'id', 'vod_id', 'channel_id'):
        v = it.get(k)
        if v is not None and str(v).strip() not in ('', '0', 'None', 'null'):
            return str(v).strip()
    return None


def compact_items(items, kind):
    if not items:
        return []
    if isinstance(items, dict):
        items = list(items.values())
    compact = []
    for it in items:
        if not isinstance(it, dict):
            continue
        item_id = get_any_id(it)
        name = (
            it.get('name') or
            it.get('title') or
            it.get('series_name') or
            it.get('stream_name') or
            it.get('channel_name')
        )
        if not item_id or not name:
            continue
        icon = it.get('cover') or it.get('stream_icon') or it.get('icon') or ''
        entry = {
            'id': item_id,
            'series_id': item_id,
            'stream_id': item_id,
            'name': str(name).strip(),
            'kind': kind,
            'icon': icon,
            'cover': icon,
            'stream_icon': icon,
        }
        if it.get('container_extension'):
            entry['container_extension'] = it.get('container_extension')
            entry['ext'] = it.get('container_extension')
        if it.get('plot'):
            entry['plot'] = str(it.get('plot'))[:300]
        if it.get('rating'):
            entry['rating'] = it.get('rating')
        if it.get('year'):
            entry['year'] = it.get('year')
        compact.append(entry)
    return compact


def load_search_index(ttl=86400):
    data = _read_json(INDEX_FILE, None)
    if not data or not isinstance(data, dict):
        return None
    if ttl is not None and time.time() - data.get('saved', 0) > ttl:
        return None
    return data


def save_search_index(shows=None, movies=None, live=None):
    existing = _read_json(INDEX_FILE, {}) or {}

    if shows is not None:
        compacted = compact_items(shows, 'series')
        if compacted or 'shows' not in existing:
            existing['shows'] = compacted
    if movies is not None:
        compacted = compact_items(movies, 'movie')
        if compacted or 'movies' not in existing:
            existing['movies'] = compacted
    if live is not None:
        compacted = compact_items(live, 'live')
        if compacted or 'live' not in existing:
            existing['live'] = compacted

    existing['saved'] = time.time()
    _write_json(INDEX_FILE, existing)


def clear_search_index():
    path = _file_path(INDEX_FILE)
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


# --- Cache Storage ---

def cache_get(name, ttl=14400):
    path = _file_path(os.path.join(CACHE_DIR, f'{name}.json'))
    if not xbmcvfs.exists(path):
        return None
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        payload = json.loads(raw)
        if ttl is not None and time.time() - payload.get('saved', 0) > ttl:
            return None
        return payload.get('data')
    except Exception:
        return None


def cache_set(name, data):
    folder = _file_path(CACHE_DIR)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    _write_json(os.path.join(CACHE_DIR, f'{name}.json'), {'saved': time.time(), 'data': data})


def clear_cache(prefix=None):
    folder = _file_path(CACHE_DIR)
    if not xbmcvfs.exists(folder):
        return
    try:
        _, files = xbmcvfs.listdir(folder)
        for fname in files:
            if not prefix or fname.startswith(prefix):
                xbmcvfs.delete(os.path.join(folder, fname))
    except Exception as exc:
        xbmc.log(f'[Wandall] clear cache error: {exc}', xbmc.LOGERROR)

# --- Multi-Playlist Storage ---

PLAYLISTS_FILE = 'playlists.json'


def load_playlists():
    data = _read_json(PLAYLISTS_FILE, {'active_id': None, 'playlists': []})
    if not isinstance(data, dict):
        data = {'active_id': None, 'playlists': []}
    return data


def save_playlists(data):
    _write_json(PLAYLISTS_FILE, data)


def get_active_playlist():
    data = load_playlists()
    active_id = data.get('active_id')
    playlists = data.get('playlists') or []
    for pl in playlists:
        if pl.get('id') == active_id:
            return pl
    return playlists[0] if playlists else None


def set_active_playlist(pl_id):
    data = load_playlists()
    for pl in data.get('playlists', []):
        if pl.get('id') == pl_id:
            data['active_id'] = pl_id
            save_playlists(data)
            return pl
    return None


def add_or_update_playlist(pl_id, name, url, user, password, ext='ts'):
    data = load_playlists()
    playlists = data.get('playlists') or []
    if not pl_id:
        pl_id = f'pl_{int(time.time())}'
    
    found = False
    for pl in playlists:
        if pl.get('id') == pl_id:
            pl.update({'name': name, 'url': url, 'user': user, 'pass': password, 'ext': ext})
            found = True
            break
    if not found:
        playlists.append({'id': pl_id, 'name': name, 'url': url, 'user': user, 'pass': password, 'ext': ext})
    
    if not data.get('active_id'):
        data['active_id'] = pl_id
    data['playlists'] = playlists
    save_playlists(data)
    return pl_id


def delete_playlist(pl_id):
    data = load_playlists()
    playlists = [pl for pl in data.get('playlists', []) if pl.get('id') != pl_id]
    if data.get('active_id') == pl_id:
        data['active_id'] = playlists[0]['id'] if playlists else None
    data['playlists'] = playlists
    save_playlists(data)


# --- Catalog Statistics ---

def get_catalog_stats():
    index = load_search_index(ttl=None) or {}
    shows_count = len(index.get('shows') or [])
    movies_count = len(index.get('movies') or [])
    live_count = len(index.get('live') or [])
    
    # Fallback to cache folder if search_index not yet generated
    if not (shows_count or movies_count or live_count):
        series_cached = cache_get('series_all', ttl=None)
        if series_cached and isinstance(series_cached, list):
            shows_count = len(series_cached)
        vod_cached = cache_get('vod_all', ttl=None)
        if vod_cached and isinstance(vod_cached, list):
            movies_count = len(vod_cached)
        live_cached = cache_get('live_all', ttl=None)
        if live_cached and isinstance(live_cached, list):
            live_count = len(live_cached)
            
    total = shows_count + movies_count + live_count
    return {
        'shows': shows_count,
        'movies': movies_count,
        'live': live_count,
        'total': total
    }
