import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
FAV_FILE = 'favorites.json'
PROGRESS_FILE = 'progress.json'
CACHE_DIR = 'cache'


def _ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def _file_path(name):
    _ensure_profile()
    return os.path.join(PROFILE, name)


def _read_json(name, default):
    path = _file_path(name)
    if not xbmcvfs.exists(path):
        return default
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        return json.loads(raw) if raw else default
    except Exception as exc:
        xbmc.log(f'[Wandall] read {name}: {exc}', xbmc.LOGERROR)
        return default


def _write_json(name, data):
    path = _file_path(name)
    payload = json.dumps(data, ensure_ascii=False)
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(payload)
    finally:
        handle.close()


def load_favorites():
    data = _read_json(FAV_FILE, {'items': []})
    items = data.get('items') if isinstance(data, dict) else []
    return items if isinstance(items, list) else []


def save_favorites(items):
    _write_json(FAV_FILE, {'items': items})


def fav_key(kind, item_id):
    return f'{kind}:{item_id}'


def is_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    return any(item.get('key') == key for item in load_favorites())


def add_favorite(item):
    items = [entry for entry in load_favorites() if entry.get('key') != item.get('key')]
    items.insert(0, item)
    save_favorites(items)


def remove_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    save_favorites([item for item in load_favorites() if item.get('key') != key])


def load_progress():
    data = _read_json(PROGRESS_FILE, {})
    return data if isinstance(data, dict) else {}


def get_progress(key):
    return load_progress().get(key)


def set_progress(key, position, total, **meta):
    if not key:
        return
    data = load_progress()
    if total and position >= max(total * 0.92, total - 30):
        data.pop(key, None)
    elif position > 10:
        entry = data.get(key) or {}
        entry.update(meta)
        entry['position'] = float(position)
        entry['total'] = float(total or 0)
        entry['updated'] = time.time()
        data[key] = entry
    else:
        return
    _write_json(PROGRESS_FILE, data)


def continue_watching():
    items = []
    for key, value in load_progress().items():
        if not isinstance(value, dict):
            continue
        if value.get('position', 0) > 10:
            items.append((key, value))
    items.sort(key=lambda pair: pair[1].get('updated', 0), reverse=True)
    return items[:50]


def cache_get(name, ttl=900):
    path = _file_path(os.path.join(CACHE_DIR, f'{name}.json'))
    if not xbmcvfs.exists(path):
        return None
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        payload = json.loads(raw)
        if time.time() - payload.get('saved', 0) > ttl:
            return None
        return payload.get('data')
    except Exception:
        return None


def cache_set(name, data):
    folder = _file_path(CACHE_DIR)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    _write_json(os.path.join(CACHE_DIR, f'{name}.json'), {'saved': time.time(), 'data': data})
