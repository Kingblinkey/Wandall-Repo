# Visual 2D Graphical Chess Board for Kodi (Pure xbmcgui WindowDialog)
import os
import time
import threading
import xbmc
import xbmcgui
import xbmcaddon
from resources.lib import chess_engine, store

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmc.translatePath(ADDON.getAddonInfo('path')) if hasattr(xbmc, 'translatePath') else ''
MEDIA_DIR = os.path.join(ADDON_PATH, 'resources', 'media', 'chess')

# Action Codes in Kodi
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_SELECT_ITEM = 7
ACTION_MOUSE_LEFT_CLICK = 100


class VisualChessWindow(xbmcgui.WindowDialog):
    def __init__(self, game_id, mode='ai', fen=None, opponent='Wandall AI', room_code=None, object_id=None, my_color='w'):
        super().__init__()
        self.game_id = game_id
        self.mode = mode
        self.opponent = opponent
        self.room_code = room_code
        self.object_id = object_id
        self.my_color = my_color  # 'w' or 'b'
        self.board = chess_engine.ChessBoard(fen)

        self.cursor_row = 6 if self.my_color == 'w' else 1
        self.cursor_col = 4
        self.selected_sq = None
        self.legal_destinations = []

        self.tile_size = 70
        self.board_x = (1280 - (self.tile_size * 8)) // 2  # 360
        self.board_y = (720 - (self.tile_size * 8)) // 2   # 80

        # UI Controls
        self.tile_controls = {}
        self.piece_controls = {}
        self.legal_dot_controls = []
        self.cursor_ctrl = None
        self.selected_ctrl = None
        self.header_label = None
        self.status_label = None
        self.info_label = None

        self._build_ui()
        self._update_board_display()

    def _get_media(self, filename):
        return os.path.join(MEDIA_DIR, filename)

    def _build_ui(self):
        # 1. Dark translucent backdrop overlay (dims Kodi background)
        bg = xbmcgui.ControlImage(0, 0, 1280, 720, self._get_media('empty.png'), colorDiffuse='0xEE0F172A')
        self.addControl(bg)

        # 2. Header banner
        header_text = f"♟️ WANDALL IPTV • CHESS CLUB ({self.mode.upper()})"
        self.header_label = xbmcgui.ControlLabel(self.board_x, 20, 560, 30, header_text, font='font13', textColor='0xFFFFD700', alignment=0x00000002)
        self.addControl(self.header_label)

        # 3. Status label (Player Turn / Check)
        self.status_label = xbmcgui.ControlLabel(self.board_x, 48, 560, 30, "White's Turn", font='font12', textColor='0xFFFFFFFF', alignment=0x00000002)
        self.addControl(self.status_label)

        # 4. Render 64 Checkerboard Background Tiles
        for r in range(8):
            for c in range(8):
                sq = r * 8 + c
                x = self.board_x + c * self.tile_size
                y = self.board_y + r * self.tile_size
                tile_tex = self._get_media('tile_light.png' if (r + c) % 2 == 0 else 'tile_dark.png')
                ctrl_tile = xbmcgui.ControlImage(x, y, self.tile_size, self.tile_size, tile_tex)
                self.addControl(ctrl_tile)
                self.tile_controls[sq] = ctrl_tile

        # 5. Selected tile overlay
        self.selected_ctrl = xbmcgui.ControlImage(self.board_x, self.board_y, self.tile_size, self.tile_size, self._get_media('tile_selected.png'))
        self.selected_ctrl.setVisible(False)
        self.addControl(self.selected_ctrl)

        # 6. Green legal move dots (pool of 28 controls)
        for _ in range(28):
            dot = xbmcgui.ControlImage(0, 0, self.tile_size, self.tile_size, self._get_media('tile_legal.png'))
            dot.setVisible(False)
            self.addControl(dot)
            self.legal_dot_controls.append(dot)

        # 7. 64 Piece Images
        for sq in range(64):
            r = sq // 8
            c = sq % 8
            x = self.board_x + c * self.tile_size
            y = self.board_y + r * self.tile_size
            piece_ctrl = xbmcgui.ControlImage(x, y, self.tile_size, self.tile_size, self._get_media('empty.png'))
            self.addControl(piece_ctrl)
            self.piece_controls[sq] = piece_ctrl

        # 8. Golden glowing cursor overlay
        cur_x = self.board_x + self.cursor_col * self.tile_size
        cur_y = self.board_y + self.cursor_row * self.tile_size
        self.cursor_ctrl = xbmcgui.ControlImage(cur_x, cur_y, self.tile_size, self.tile_size, self._get_media('tile_cursor.png'))
        self.addControl(self.cursor_ctrl)

        # 9. Bottom instructions & help
        room_sub = f"Room: {self.room_code} | " if self.room_code else ""
        help_text = f"{room_sub}D-Pad: Move Cursor  •  A (Select): Pick Up / Place Piece  •  Back: Exit"
        self.info_label = xbmcgui.ControlLabel(self.board_x, self.board_y + (8 * self.tile_size) + 12, 560, 25, help_text, font='font10', textColor='0xFF94A3B8', alignment=0x00000002)
        self.addControl(self.info_label)

    def _update_cursor_pos(self):
        x = self.board_x + self.cursor_col * self.tile_size
        y = self.board_y + self.cursor_row * self.tile_size
        self.cursor_ctrl.setPosition(x, y)

    def _update_board_display(self):
        # Update pieces on board
        for sq in range(64):
            p = self.board.board[sq]
            ctrl = self.piece_controls[sq]
            if p == '.':
                ctrl.setImage(self._get_media('empty.png'))
            else:
                color_prefix = 'w' if p.isupper() else 'b'
                piece_type = p.lower()
                ctrl.setImage(self._get_media(f'{color_prefix}_{piece_type}.png'))

        # Update status line
        turn_text = "♔ White's Turn" if self.board.turn == 'w' else "♚ Black's Turn"
        if self.board.is_in_check(self.board.turn):
            turn_text += " [CHECK!]"
        over, over_msg = self.board.is_game_over()
        if over:
            turn_text = f"GAME OVER: {over_msg}"

        opp_label = f"vs {self.opponent}"
        self.status_label.setLabel(f"{turn_text} • {opp_label}")

        # Update selected highlight
        if self.selected_sq is not None:
            r = self.selected_sq // 8
            c = self.selected_sq % 8
            self.selected_ctrl.setPosition(self.board_x + c * self.tile_size, self.board_y + r * self.tile_size)
            self.selected_ctrl.setVisible(True)
        else:
            self.selected_ctrl.setVisible(False)

        # Update legal destination dots
        for idx, dot in enumerate(self.legal_dot_controls):
            if idx < len(self.legal_destinations):
                dst_sq = self.legal_destinations[idx]
                r = dst_sq // 8
                c = dst_sq % 8
                dot.setPosition(self.board_x + c * self.tile_size, self.board_y + r * self.tile_size)
                dot.setVisible(True)
            else:
                dot.setVisible(False)

    def _save_current_state(self, last_move=None):
        game_data = {
            'id': self.game_id,
            'mode': self.mode,
            'fen': self.board.get_fen(),
            'turn': self.board.turn,
            'my_color': self.my_color,
            'opponent': self.opponent,
            'room_code': self.room_code,
            'object_id': self.object_id,
            'last_move': last_move,
        }
        store.save_chess_game(self.game_id, game_data)

    def _handle_click(self):
        clicked_sq = self.cursor_row * 8 + self.cursor_col
        over, _ = self.board.is_game_over()
        if over:
            return

        # 1. If no piece selected yet: pick up piece if it belongs to current player's turn
        if self.selected_sq is None:
            p = self.board.board[clicked_sq]
            if p == '.':
                return
            is_own = (self.board.turn == 'w' and p.isupper()) or (self.board.turn == 'b' and p.islower())
            if not is_own:
                return

            legal_moves = self.board.get_legal_moves()
            destinations = [m[1] for m in legal_moves if m[0] == clicked_sq]
            if destinations:
                self.selected_sq = clicked_sq
                self.legal_destinations = destinations
                self._update_board_display()

        # 2. If piece was already selected
        else:
            # If clicked on legal destination: execute move!
            if clicked_sq in self.legal_destinations:
                legal_moves = self.board.get_legal_moves()
                chosen_move = next((m for m in legal_moves if m[0] == self.selected_sq and m[1] == clicked_sq), None)
                if chosen_move:
                    uci_str = self.board.move_to_uci(chosen_move)
                    self.board.make_move(chosen_move)
                    self.selected_sq = None
                    self.legal_destinations = []
                    self._update_board_display()
                    self._save_current_state(last_move=uci_str)

                    # Trigger AI move if in AI mode and not game over
                    over_after, _ = self.board.is_game_over()
                    if not over_after and self.mode == 'ai':
                        threading.Thread(target=self._ai_response_thread, daemon=True).start()

                    # Push move to Room Code Relay if online
                    elif self.mode == 'room' and self.object_id:
                        threading.Thread(target=self._send_room_move, args=(uci_str,), daemon=True).start()

            # If clicked on another piece of own color: switch selection
            else:
                p = self.board.board[clicked_sq]
                is_own = (self.board.turn == 'w' and p.isupper()) or (self.board.turn == 'b' and p.islower())
                if is_own:
                    legal_moves = self.board.get_legal_moves()
                    destinations = [m[1] for m in legal_moves if m[0] == clicked_sq]
                    self.selected_sq = clicked_sq
                    self.legal_destinations = destinations
                    self._update_board_display()
                else:
                    self.selected_sq = None
                    self.legal_destinations = []
                    self._update_board_display()

    def _ai_response_thread(self):
        time.sleep(0.4)  # Small natural pause so player sees their move
        ai_move = self.board.get_best_move(depth=2)
        if ai_move:
            uci_ai = self.board.move_to_uci(ai_move)
            self.board.make_move(ai_move)
            self._update_board_display()
            self._save_current_state(last_move=uci_ai)

    def _send_room_move(self, uci_str):
        chess_engine.WandallRoomRelay.send_move(
            self.object_id,
            self.room_code,
            self.board.get_fen(),
            uci_str,
            "Player"
        )

    def onAction(self, action):
        action_id = action.getId()

        # D-Pad Movement across 8x8 squares
        if action_id == ACTION_MOVE_LEFT:
            self.cursor_col = max(0, self.cursor_col - 1)
            self._update_cursor_pos()
        elif action_id == ACTION_MOVE_RIGHT:
            self.cursor_col = min(7, self.cursor_col + 1)
            self._update_cursor_pos()
        elif action_id == ACTION_MOVE_UP:
            self.cursor_row = max(0, self.cursor_row - 1)
            self._update_cursor_pos()
        elif action_id == ACTION_MOVE_DOWN:
            self.cursor_row = min(7, self.cursor_row + 1)
            self._update_cursor_pos()

        # A Button (Select) -> Pick Up / Move Piece
        elif action_id in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
            self._handle_click()

        # Back Button -> Close Window
        elif action_id in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.close()
