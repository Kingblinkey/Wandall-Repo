import sys
import json
import ssl
import time
import urllib.request
import urllib.parse
import urllib.error
import concurrent.futures
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import store

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
PLUGIN = sys.argv[0] if sys.argv else 'plugin://plugin.video.wandall/'
USER_AGENT = 'TiviMate/4.7.0 (Linux; Android 9; Fire TV)'


def get_settings():
    source_type = ADDON.getSetting('source_type') or 'Xtream Codes'
    xc_url = normalize_xc_url(ADDON.getSetting('xc_url'))
    xc_user = ADDON.getSetting('xc_user').strip()
    xc_pass = ADDON.getSetting('xc_pass').strip()
    m3u_url = ADDON.getSetting('m3u_url').strip()
    output_ext = (ADDON.getSetting('output_ext') or 'ts').strip().lstrip('.')
    return source_type, xc_url, xc_user, xc_pass, m3u_url, output_ext


def is_xtream():
    source_type, *_ = get_settings()
    return source_type in ('Xtream Codes', '0', '')


def normalize_xc_url(raw):
    url = (raw or '').strip()
    if not url:
        return ''
    parsed = urllib.parse.urlparse(url)
    if not parsed.scheme:
        url = 'http://' + url
        parsed = urllib.parse.urlparse(url)
    path = parsed.path.rstrip('/')
    for suffix in ('/player_api.php', '/get.php', '/xmltv.php', '/c'):
        if path.lower().endswith(suffix):
            path = path[: -len(suffix)]
            break
    cleaned = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, path, '', '', ''))
    return cleaned.rstrip('/')


def creds(user, password):
    return urllib.parse.quote(user, safe=''), urllib.parse.quote(password, safe='')


def with_ua(url):
    if '|' in url:
        return url
    ua = urllib.parse.quote(USER_AGENT, safe='')
    return f'{url}|User-Agent={ua}&Connection=keep-alive'


def plugin_url(**kwargs):
    cleaned = {key: '' if value is None else value for key, value in kwargs.items()}
    return f'{PLUGIN}?{urllib.parse.urlencode(cleaned, doseq=True)}'


def http_get(url):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Connection': 'close'})
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
        charset = resp.headers.get_content_charset() or 'utf-8'
        return resp.read().decode(charset, errors='replace')


def notify(message, heading='Wandall', icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(heading, message, icon)


def require_xc():
    _, xc_url, xc_user, xc_pass, _, _ = get_settings()
    if not xc_url or not xc_user or not xc_pass:
        notify('Missing credentials', icon=xbmcgui.NOTIFICATION_WARNING)
        return None
    return xc_url, xc_user, xc_pass


def parse_xtream_payload(raw, expect_list=True):
    data = json.loads(raw)
    if isinstance(data, dict) and 'user_info' in data:
        auth = str(data.get('user_info', {}).get('auth', '0'))
        if auth in ('0', 'false', 'False'):
            raise RuntimeError('Xtream login failed. Check server URL, username, and password.')
        if expect_list:
            raise RuntimeError('Server did not return a list.')
    if expect_list and not isinstance(data, list):
        raise RuntimeError('Unexpected response from IPTV server.')
    return data


def xc_request(action, expect_list=True, cache_name=None, ttl=3600, **params):
    cred = require_xc()
    if not cred:
        return None
    xc_url, xc_user, xc_pass = cred
    if cache_name:
        cached = store.cache_get(cache_name, ttl=ttl)
        if cached is not None:
            return cached
    query = [('username', xc_user), ('password', xc_pass), ('action', action)]
    for key, value in params.items():
        if value is not None and value != '':
            query.append((key, value))
    url = f'{xc_url}/player_api.php?{urllib.parse.urlencode(query)}'
    data = parse_xtream_payload(http_get(url), expect_list=expect_list)
    if cache_name:
        store.cache_set(cache_name, data)
    return data


def art_from(*urls):
    picture = next((url for url in urls if url), '')
    if not picture:
        return None
    return {'thumb': picture, 'icon': picture, 'poster': picture, 'fanart': picture}


def add_item(label, url, is_folder=True, art=None, is_playable=False, info=None, context=None, mediatype=None):
    li = xbmcgui.ListItem(label=label)
    video = {'title': label}
    if info:
        video.update({key: value for key, value in info.items() if value not in (None, '')})
    if mediatype:
        video['mediatype'] = mediatype
    li.setInfo('video', video)
    if art:
        li.setArt(art)
    if is_playable:
        li.setProperty('IsPlayable', 'true')
    if context:
        li.addContextMenuItems(context, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)


def finish_directory(succeeded=True, content='videos'):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded, cacheToDisc=False)


def fav_context(kind, item_id, label, target, icon=''):
    if store.is_favorite(kind, item_id):
        return [('Remove from Wandall Favorites', f'RunPlugin({plugin_url(action="fav_remove", kind=kind, item_id=item_id)})')]
    return [('Add to Wandall Favorites', f'RunPlugin({plugin_url(action="fav_add", kind=kind, item_id=item_id, label=label, target=target, icon=icon)})')]


def stream_url(kind, item_id, extension):
    cred = require_xc()
    if not cred:
        return ''
    xc_url, xc_user, xc_pass = cred
    user, password = creds(xc_user, xc_pass)
    ext = (extension or 'mp4').lstrip('.')
    path = {'live': 'live', 'movie': 'movie', 'episode': 'series'}[kind]
    return f'{xc_url}/{path}/{user}/{password}/{item_id}.{ext}'


def ask_search():
    keyboard = xbmc.Keyboard('', 'Search Wandall')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return ''
    return (keyboard.getText() or '').strip()


def matches(query, *values):
    needle = query.lower()
    return any(needle in str(value).lower() for value in values if value)


def parse_duration(raw):
    if not raw:
        return None
    text = str(raw).strip()
    if text.isdigit():
        value = int(text)
        return value * 60 if value < 300 else value
    parts = text.split(':')
    try:
        parts = [int(part) for part in parts]
    except ValueError:
        return None
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds or None


def get_numeric_rating(item):
    try:
        r = item.get('rating')
        if r is not None and str(r).strip() not in ('', '0'):
            return float(r)
        r5 = item.get('rating_5based')
        if r5 is not None and str(r5).strip() not in ('', '0'):
            return float(r5) * 2.0
    except (ValueError, TypeError):
        pass
    return 0.0


def get_timestamp(item):
    for field in ('added', 'last_modified', 'release_date'):
        val = item.get(field)
        if val and str(val).isdigit():
            return int(val)
    return 0


# --- Root Menu ---

def build_root_menu():
    source_type, xc_url, xc_user, xc_pass, m3u_url, _ = get_settings()
    add_item('Search', plugin_url(action='search_menu'))
    add_item('Recommended', plugin_url(action='recommended_menu'))
    add_item('Favorites', plugin_url(action='favorites'))
    add_item('Watch History', plugin_url(action='history_menu'))
    if store.continue_watching():
        add_item('Continue Watching', plugin_url(action='continue_watching'))

    if is_xtream():
        add_item('Live TV', plugin_url(action='list_categories'))
        add_item('Movies', plugin_url(action='list_vod_categories'))
        add_item('TV Shows', plugin_url(action='list_series_categories'))
        add_item('All Live Channels', plugin_url(action='list_streams'))
    else:
        add_item('M3U Channels', plugin_url(action='list_m3u'))

    add_item('Configure Wandall Settings', plugin_url(action='open_settings'))
    finish_directory()

    if is_xtream() and not (xc_url and xc_user and xc_pass):
        notify('Set your Xtream server, username, and password', icon=xbmcgui.NOTIFICATION_WARNING)
    elif not is_xtream() and not m3u_url:
        notify('Set your M3U URL in settings', icon=xbmcgui.NOTIFICATION_WARNING)


# --- Category Listings ---

def list_named_categories(action, next_action, cache_name, empty_message):
    try:
        categories = xc_request(action, cache_name=cache_name, ttl=7200)
        if categories is None:
            finish_directory(False)
            return
        if not categories:
            notify(empty_message)
            finish_directory(True)
            return
        for cat in categories:
            cat_id = cat.get('category_id')
            name = cat.get('category_name') or 'Unnamed Category'
            add_item(name, plugin_url(action=next_action, category_id=cat_id or ''))
        finish_directory()
    except Exception as exc:
        xbmc.log(f'[Wandall] {action}: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80], 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_live_categories():
    list_named_categories('get_live_categories', 'list_streams', 'live_categories', 'No live categories')


def list_vod_categories():
    list_named_categories('get_vod_categories', 'list_movies', 'vod_categories', 'No movie categories')


def list_series_categories():
    list_named_categories('get_series_categories', 'list_series', 'series_categories', 'No TV show categories')


# --- Stream Item Helpers ---

def add_live_item(stream, output_ext):
    stream_id = stream.get('stream_id')
    if not stream_id:
        return
    name = stream.get('name') or 'Live Channel'
    icon = stream.get('stream_icon') or ''
    play = plugin_url(action='play', kind='live', item_id=stream_id, ext=output_ext, title=name, icon=icon)
    add_item(
        name,
        play,
        is_folder=False,
        art=art_from(icon),
        is_playable=True,
        mediatype='video',
        context=fav_context('live', stream_id, name, play, icon),
    )


def add_movie_item(movie):
    stream_id = movie.get('stream_id')
    if not stream_id:
        return
    name = movie.get('name') or 'Movie'
    icon = movie.get('stream_icon') or movie.get('cover') or ''
    ext = movie.get('container_extension') or 'mp4'
    play = plugin_url(action='play', kind='movie', item_id=stream_id, ext=ext, title=name, media_key=f'movie:{stream_id}', icon=icon)
    add_item(
        name,
        play,
        is_folder=False,
        art=art_from(icon),
        is_playable=True,
        mediatype='movie',
        info={'plot': movie.get('plot'), 'year': movie.get('year'), 'rating': movie.get('rating')},
        context=fav_context('movie', stream_id, name, play, icon),
    )


def add_series_item(show):
    series_id = show.get('series_id')
    if not series_id:
        return
    name = show.get('name') or 'TV Show'
    icon = show.get('cover') or show.get('stream_icon') or ''
    target = plugin_url(action='list_seasons', series_id=series_id, title=name, icon=icon)
    add_item(
        name,
        target,
        art=art_from(icon),
        mediatype='tvshow',
        info={'plot': show.get('plot'), 'year': show.get('year'), 'rating': show.get('rating')},
        context=fav_context('series', series_id, name, target, icon),
    )


def list_streams(category_id):
    _, _, _, _, _, output_ext = get_settings()
    try:
        cache_name = f'live_{category_id or "all"}'
        streams = xc_request('get_live_streams', cache_name=cache_name, category_id=category_id, ttl=3600)
        if streams is None:
            finish_directory(False)
            return
        for stream in streams:
            add_live_item(stream, output_ext)
        finish_directory(content='videos')
    except Exception as exc:
        xbmc.log(f'[Wandall] live streams: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load streams', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_movies(category_id):
    try:
        cache_name = f'vod_{category_id or "all"}'
        movies = xc_request('get_vod_streams', cache_name=cache_name, category_id=category_id, ttl=3600)
        if movies is None:
            finish_directory(False)
            return
        for movie in movies:
            add_movie_item(movie)
        finish_directory(content='movies')
    except Exception as exc:
        xbmc.log(f'[Wandall] movies: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load movies', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_series(category_id):
    try:
        cache_name = f'series_{category_id or "all"}'
        shows = xc_request('get_series', cache_name=cache_name, category_id=category_id, ttl=3600)
        if shows is None:
            finish_directory(False)
            return
        for show in shows:
            add_series_item(show)
        finish_directory(content='tvshows')
    except Exception as exc:
        xbmc.log(f'[Wandall] series: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load TV shows', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_seasons(series_id, title, icon):
    try:
        payload = xc_request('get_series_info', expect_list=False, series_id=series_id, ttl=3600)
        if payload is None:
            finish_directory(False)
            return
        info = payload.get('info') or {}
        episodes = payload.get('episodes') or {}
        cover = info.get('cover') or icon
        seasons = sorted(episodes.keys(), key=lambda value: int(value) if str(value).isdigit() else str(value))
        for season in seasons:
            label = f'{title} - Season {season}' if title else f'Season {season}'
            add_item(
                label,
                plugin_url(action='list_episodes', series_id=series_id, season=season, title=title or '', icon=cover or ''),
                art=art_from(cover),
                mediatype='season',
            )
        if not seasons:
            notify('No seasons found')
        finish_directory(content='tvshows')
    except Exception as exc:
        xbmc.log(f'[Wandall] seasons: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load seasons', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_episodes(series_id, season, title, icon):
    try:
        payload = xc_request('get_series_info', expect_list=False, series_id=series_id, ttl=3600)
        if payload is None:
            finish_directory(False)
            return
        info = payload.get('info') or {}
        episodes = (payload.get('episodes') or {}).get(str(season)) or (payload.get('episodes') or {}).get(season) or []
        cover = info.get('cover') or icon
        for episode in episodes:
            episode_id = episode.get('id')
            if not episode_id:
                continue
            ep_info = episode.get('info') or {}
            number = episode.get('episode_num') or episode.get('episode') or ''
            ep_title = episode.get('title') or ep_info.get('name') or f'Episode {number}'
            label = f'S{str(season).zfill(2)}E{str(number).zfill(2)} - {ep_title}'
            ext = episode.get('container_extension') or 'mp4'
            thumb = ep_info.get('movie_image') or cover
            media_key = f'episode:{episode_id}'
            play = plugin_url(action='play', kind='episode', item_id=episode_id, ext=ext, title=label, media_key=media_key, icon=thumb or cover)
            add_item(
                label,
                play,
                is_folder=False,
                art=art_from(thumb),
                is_playable=True,
                mediatype='episode',
                info={
                    'plot': ep_info.get('plot') or info.get('plot'),
                    'duration': parse_duration(ep_info.get('duration')),
                    'tvshowtitle': title,
                    'season': season,
                    'episode': number,
                },
                context=fav_context('episode', episode_id, label, play, thumb or ''),
            )
        finish_directory(content='episodes')
    except Exception as exc:
        xbmc.log(f'[Wandall] episodes: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load episodes', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def list_m3u(query=None):
    _, _, _, _, m3u_url, _ = get_settings()
    if not m3u_url:
        notify('Missing M3U URL', icon=xbmcgui.NOTIFICATION_WARNING)
        finish_directory(False)
        return
    try:
        content = http_get(m3u_url)
        current_name = None
        current_logo = ''
        added = 0
        needle = query.lower() if query else None
        for line in content.splitlines():
            line = line.strip()
            if line.startswith('#EXTINF:'):
                current_name = line.split(',', 1)[-1].strip() if ',' in line else 'Channel'
                current_logo = ''
                for token in line.split(' '):
                    if token.startswith('tvg-logo='):
                        current_logo = token.split('=', 1)[-1].strip('"\'')
            elif line and not line.startswith('#'):
                name = current_name or 'Channel'
                if needle and needle not in name.lower():
                    current_name = None
                    continue
                play = plugin_url(action='play', kind='m3u', url=line, title=name, media_key=f'm3u:{name}', icon=current_logo)
                add_item(
                    name,
                    play,
                    is_folder=False,
                    art=art_from(current_logo),
                    is_playable=True,
                    context=fav_context('m3u', name, name, play, current_logo),
                )
                added += 1
                current_name = None
                current_logo = ''
        if not added:
            notify('No channels found')
        finish_directory()
    except Exception as exc:
        xbmc.log(f'[Wandall] m3u: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Could not load M3U', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


# --- Fast Search Implementation ---

def search_menu():
    add_item('Search All Categories', plugin_url(action='search', scope='all'))
    add_item('Search Movies Only', plugin_url(action='search', scope='movie'))
    add_item('Search TV Shows Only', plugin_url(action='search', scope='series'))
    add_item('Search Live TV Channels', plugin_url(action='search', scope='live'))
    add_item('[Clear Search Cache]', plugin_url(action='clear_search_cache'))
    finish_directory()


def run_search(query=None, scope='all'):
    query = query or ask_search()
    if not query:
        finish_directory(False)
        return
    if not is_xtream():
        list_m3u(query)
        return

    _, _, _, _, _, output_ext = get_settings()
    needle = query.strip().lower()
    added = 0
    limit = 60

    try:
        shows, movies, live = [], [], []

        if scope == 'movie':
            movies = xc_request('get_vod_streams', cache_name='vod_all', ttl=7200) or []
        elif scope == 'series':
            shows = xc_request('get_series', cache_name='series_all', ttl=7200) or []
        elif scope == 'live':
            live = xc_request('get_live_streams', cache_name='live_all', ttl=7200) or []
        else:
            # Parallel multi-category retrieval for maximum speed
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                f_shows = executor.submit(xc_request, 'get_series', cache_name='series_all', ttl=7200)
                f_movies = executor.submit(xc_request, 'get_vod_streams', cache_name='vod_all', ttl=7200)
                f_live = executor.submit(xc_request, 'get_live_streams', cache_name='live_all', ttl=7200)
                shows = f_shows.result() or []
                movies = f_movies.result() or []
                live = f_live.result() or []

        # Streamlined in-memory search
        count_shows = 0
        for show in shows:
            if needle in (show.get('name') or '').lower() or needle in (show.get('plot') or '').lower():
                add_series_item(show)
                added += 1
                count_shows += 1
                if count_shows >= limit:
                    break

        count_movies = 0
        for movie in movies:
            if needle in (movie.get('name') or '').lower() or needle in (movie.get('plot') or '').lower():
                add_movie_item(movie)
                added += 1
                count_movies += 1
                if count_movies >= limit:
                    break

        count_live = 0
        for stream in live:
            if needle in (stream.get('name') or '').lower():
                add_live_item(stream, output_ext)
                added += 1
                count_live += 1
                if count_live >= limit:
                    break

        if not added:
            notify(f'No results for "{query}"')
        else:
            notify(f'Found {added} match(es)')
        finish_directory()
    except Exception as exc:
        xbmc.log(f'[Wandall] search: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Search failed', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


def clear_search_cache():
    store.clear_cache('vod_')
    store.clear_cache('series_')
    store.clear_cache('live_')
    notify('Search cache refreshed')
    xbmc.executebuiltin('Container.Refresh')


# --- Recommended Section ---

def recommended_menu():
    add_item('Recommended For You', plugin_url(action='list_recommended', rec_type='for_you'))
    add_item('Top Rated Movies', plugin_url(action='list_recommended', rec_type='top_movies'))
    add_item('Top Rated TV Shows', plugin_url(action='list_recommended', rec_type='top_series'))
    add_item('Recently Added Movies', plugin_url(action='list_recommended', rec_type='recent_movies'))
    add_item('Recently Added TV Shows', plugin_url(action='list_recommended', rec_type='recent_series'))
    finish_directory()


def list_recommended(rec_type):
    if not is_xtream():
        notify('Recommendations require Xtream Codes source', icon=xbmcgui.NOTIFICATION_WARNING)
        finish_directory(True)
        return

    try:
        if rec_type == 'top_movies':
            movies = xc_request('get_vod_streams', cache_name='vod_all', ttl=7200) or []
            rated = [m for m in movies if get_numeric_rating(m) >= 6.5]
            rated.sort(key=get_numeric_rating, reverse=True)
            for m in rated[:50]:
                add_movie_item(m)
            finish_directory(content='movies')

        elif rec_type == 'top_series':
            shows = xc_request('get_series', cache_name='series_all', ttl=7200) or []
            rated = [s for s in shows if get_numeric_rating(s) >= 6.5]
            rated.sort(key=get_numeric_rating, reverse=True)
            for s in rated[:50]:
                add_series_item(s)
            finish_directory(content='tvshows')

        elif rec_type == 'recent_movies':
            movies = xc_request('get_vod_streams', cache_name='vod_all', ttl=7200) or []
            movies_sorted = sorted(movies, key=lambda m: (get_timestamp(m), int(m.get('stream_id', 0) or 0)), reverse=True)
            for m in movies_sorted[:50]:
                add_movie_item(m)
            finish_directory(content='movies')

        elif rec_type == 'recent_series':
            shows = xc_request('get_series', cache_name='series_all', ttl=7200) or []
            shows_sorted = sorted(shows, key=lambda s: (get_timestamp(s), int(s.get('series_id', 0) or 0)), reverse=True)
            for s in shows_sorted[:50]:
                add_series_item(s)
            finish_directory(content='tvshows')

        elif rec_type == 'for_you':
            history = store.load_history()
            favs = store.load_favorites()
            history_keys = {item.get('key') for item in history}

            # Discover user interests based on history and favorites
            movies = xc_request('get_vod_streams', cache_name='vod_all', ttl=7200) or []
            shows = xc_request('get_series', cache_name='series_all', ttl=7200) or []

            fav_categories = {}
            for item in history + favs:
                cat = item.get('category_id')
                if cat:
                    fav_categories[str(cat)] = fav_categories.get(str(cat), 0) + 1

            recs = []
            if fav_categories:
                top_cats = sorted(fav_categories.keys(), key=lambda c: fav_categories[c], reverse=True)[:3]
                matched_movies = [m for m in movies if str(m.get('category_id')) in top_cats and f"movie:{m.get('stream_id')}" not in history_keys]
                matched_shows = [s for s in shows if str(s.get('category_id')) in top_cats and f"series:{s.get('series_id')}" not in history_keys]
                matched_movies.sort(key=get_numeric_rating, reverse=True)
                matched_shows.sort(key=get_numeric_rating, reverse=True)
                recs = matched_movies[:25] + matched_shows[:25]

            if not recs:
                # Fallback: Top rated movies and shows
                top_m = sorted(movies, key=get_numeric_rating, reverse=True)[:25]
                top_s = sorted(shows, key=get_numeric_rating, reverse=True)[:25]
                recs = top_m + top_s

            for item in recs:
                if 'stream_id' in item:
                    add_movie_item(item)
                elif 'series_id' in item:
                    add_series_item(item)
            finish_directory()
        else:
            finish_directory(True)

    except Exception as exc:
        xbmc.log(f'[Wandall] recommended: {exc}', xbmc.LOGERROR)
        notify(str(exc)[:80] or 'Failed to load recommendations', 'Wandall Error', xbmcgui.NOTIFICATION_ERROR)
        finish_directory(False)


# --- Watch History Implementation ---

def history_menu():
    add_item('All Watch History', plugin_url(action='list_history', filter='all'))
    add_item('Movies History', plugin_url(action='list_history', filter='movie'))
    add_item('TV Shows History', plugin_url(action='list_history', filter='series'))
    add_item('Live TV History', plugin_url(action='list_history', filter='live'))
    add_item('[Clear Watch History]', plugin_url(action='clear_history_menu'))
    finish_directory()


def clear_history_menu():
    add_item('Clear All Watch History', plugin_url(action='do_clear_history', filter='all'))
    add_item('Clear Movies History', plugin_url(action='do_clear_history', filter='movie'))
    add_item('Clear TV Shows History', plugin_url(action='do_clear_history', filter='series'))
    add_item('Clear Live TV History', plugin_url(action='do_clear_history', filter='live'))
    finish_directory()


def do_clear_history(params):
    filter_kind = params.get('filter') or 'all'
    names = {
        'all': 'All Watch History',
        'movie': 'Movies Watch History',
        'series': 'TV Shows Watch History',
        'live': 'Live TV Watch History',
    }
    label = names.get(filter_kind, 'Watch History')
    if xbmcgui.Dialog().yesno('Clear History', f'Are you sure you want to clear {label}?'):
        store.clear_history(filter_kind)
        notify(f'Cleared {label}')
        xbmc.executebuiltin('Container.Refresh')


def remove_history_item(params):
    key = params.get('key')
    if key:
        store.remove_history(key)
        notify('Removed from watch history')
        xbmc.executebuiltin('Container.Refresh')


def list_history(filter_kind='all'):
    items = store.get_history(filter_kind)
    if not items:
        notify('No watch history in this category')
        finish_directory(True)
        return

    for item in items:
        key = item.get('key') or ''
        title = item.get('title') or 'Unknown Title'
        kind = item.get('kind') or 'vod'
        item_id = item.get('item_id') or ''
        ext = item.get('ext') or 'mp4'
        icon = item.get('icon') or ''
        url = item.get('url') or ''

        target = plugin_url(action='play', kind=kind, item_id=item_id, ext=ext, title=title, media_key=key, url=url, icon=icon)
        context = [
            ('Remove from Watch History', f'RunPlugin({plugin_url(action="remove_history", key=key)})')
        ]
        if kind and item_id:
            context.extend(fav_context(kind, item_id, title, target, icon))

        mediatype = 'video'
        if kind == 'movie':
            mediatype = 'movie'
        elif kind in ('episode', 'series'):
            mediatype = 'episode'

        add_item(
            title,
            target,
            is_folder=False,
            art=art_from(icon),
            is_playable=True,
            mediatype=mediatype,
            context=context,
        )
    finish_directory()


# --- Favorites & Continue Watching ---

def list_favorites():
    items = store.load_favorites()
    if not items:
        notify('No favorites yet. Use the context menu on a title.')
        finish_directory(True)
        return
    for item in items:
        add_item(
            item.get('label') or 'Favorite',
            item.get('target') or PLUGIN,
            is_folder=item.get('kind') == 'series',
            art=art_from(item.get('icon')),
            is_playable=item.get('kind') != 'series',
            context=fav_context(item.get('kind'), item.get('item_id'), item.get('label'), item.get('target'), item.get('icon') or ''),
        )
    finish_directory()


def list_continue_watching():
    items = store.continue_watching()
    if not items:
        notify('Nothing to continue')
        finish_directory(True)
        return
    for key, data in items:
        kind, item_id = (key.split(':', 1) + [''])[:2]
        title = data.get('title') or key
        ext = data.get('ext') or 'mp4'
        icon = data.get('icon') or ''
        play = plugin_url(action='play', kind=kind, item_id=item_id, ext=ext, title=title, media_key=key, url=data.get('url') or '', icon=icon)
        add_item(title, play, is_folder=False, is_playable=True, art=art_from(icon), mediatype='movie' if kind == 'movie' else 'episode')
    finish_directory()


def fav_add(params):
    kind = params.get('kind')
    item_id = params.get('item_id')
    if not kind or not item_id:
        return
    store.add_favorite({
        'key': store.fav_key(kind, item_id),
        'kind': kind,
        'item_id': item_id,
        'label': params.get('label') or item_id,
        'target': params.get('target') or '',
        'icon': params.get('icon') or '',
    })
    notify('Added to favorites')
    xbmc.executebuiltin('Container.Refresh')


def fav_remove(params):
    store.remove_favorite(params.get('kind'), params.get('item_id'))
    notify('Removed from favorites')
    xbmc.executebuiltin('Container.Refresh')


# --- Playback Management ---

def play_item(params):
    kind = params.get('kind') or 'vod'
    item_id = params.get('item_id')
    ext = params.get('ext') or 'mp4'
    title = params.get('title') or ''
    media_key = params.get('media_key') or (f'{kind}:{item_id}' if item_id else '')
    url = params.get('url') or ''
    icon = params.get('icon') or ''

    if not url:
        if kind == 'live':
            url = stream_url('live', item_id, ext)
        elif kind == 'movie':
            url = stream_url('movie', item_id, ext)
        elif kind == 'episode':
            url = stream_url('episode', item_id, ext)

    if not url:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        notify('Missing stream URL', icon=xbmcgui.NOTIFICATION_ERROR)
        return

    # Automatically record to watch history
    store.add_history({
        'key': media_key or f'{kind}:{item_id or title}',
        'kind': kind,
        'item_id': item_id,
        'title': title,
        'ext': ext,
        'url': url if kind in ('vod', 'm3u') else '',
        'icon': icon,
        'watched_at': time.time(),
    })

    li = xbmcgui.ListItem(path=with_ua(url), label=title)
    mediatype = 'video'
    if kind == 'movie':
        mediatype = 'movie'
    elif kind == 'episode':
        mediatype = 'episode'
    li.setInfo('video', {'title': title, 'mediatype': mediatype})
    li.setProperty('IsPlayable', 'true')
    if art_from(icon):
        li.setArt(art_from(icon))

    if kind != 'live':
        saved = store.get_progress(media_key) or {}
        position = float(saved.get('position') or 0)
        total = float(saved.get('total') or 0)
        if position > 30:
            li.setProperty('ResumeTime', str(position))
            li.setProperty('TotalTime', str(total if total > position else position + 1))
            try:
                li.getVideoInfoTag().setResumePoint(position, total if total > position else position + 1)
            except Exception:
                pass

    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    if kind != 'live':
        watch_and_save(media_key, title, ext, url if kind == 'vod' else '', icon)


def watch_and_save(media_key, title, ext, url, icon=''):
    if not media_key:
        return
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    waited = 0
    while not player.isPlaying() and not monitor.abortRequested() and waited < 15000:
        monitor.waitForAbort(0.25)
        waited += 250
    while player.isPlaying() and not monitor.abortRequested():
        try:
            store.set_progress(
                media_key,
                player.getTime(),
                player.getTotalTime(),
                title=title,
                ext=ext,
                url=url,
                icon=icon,
            )
        except Exception:
            pass
        monitor.waitForAbort(5)


def open_settings():
    ADDON.openSettings()
    xbmc.executebuiltin('Container.Refresh')
    finish_directory()


# --- URL Router ---

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring, keep_blank_values=True))
    action = params.get('action')

    if not action:
        build_root_menu()
    elif action == 'list_categories':
        list_live_categories()
    elif action == 'list_streams':
        list_streams(params.get('category_id'))
    elif action == 'list_vod_categories':
        list_vod_categories()
    elif action == 'list_movies':
        list_movies(params.get('category_id'))
    elif action == 'list_series_categories':
        list_series_categories()
    elif action == 'list_series':
        list_series(params.get('category_id'))
    elif action == 'list_seasons':
        list_seasons(params.get('series_id'), params.get('title'), params.get('icon'))
    elif action == 'list_episodes':
        list_episodes(params.get('series_id'), params.get('season'), params.get('title'), params.get('icon'))
    elif action == 'list_m3u':
        list_m3u()
    elif action == 'search_menu':
        search_menu()
    elif action == 'search':
        run_search(params.get('query'), params.get('scope') or 'all')
    elif action == 'clear_search_cache':
        clear_search_cache()
    elif action == 'recommended_menu':
        recommended_menu()
    elif action == 'list_recommended':
        list_recommended(params.get('rec_type') or 'for_you')
    elif action == 'history_menu':
        history_menu()
    elif action == 'list_history':
        list_history(params.get('filter') or 'all')
    elif action == 'clear_history_menu':
        clear_history_menu()
    elif action == 'do_clear_history':
        do_clear_history(params)
    elif action == 'remove_history':
        remove_history_item(params)
    elif action == 'favorites':
        list_favorites()
    elif action == 'continue_watching':
        list_continue_watching()
    elif action == 'fav_add':
        fav_add(params)
    elif action == 'fav_remove':
        fav_remove(params)
    elif action == 'play':
        play_item(params)
    elif action == 'open_settings':
        open_settings()
    else:
        build_root_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
