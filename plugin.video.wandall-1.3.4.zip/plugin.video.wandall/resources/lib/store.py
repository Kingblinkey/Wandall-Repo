import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
FAV_FILE = 'favorites.json'
PROGRESS_FILE = 'progress.json'
HISTORY_FILE = 'history.json'
INDEX_FILE = 'search_index.json'
CACHE_DIR = 'cache'


def _ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def _file_path(name):
    _ensure_profile()
    return os.path.join(PROFILE, name)


def _read_json(name, default):
    path = _file_path(name)
    if not xbmcvfs.exists(path):
        return default
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        return json.loads(raw) if raw else default
    except Exception as exc:
        xbmc.log(f'[Wandall] read {name}: {exc}', xbmc.LOGERROR)
        return default


def _write_json(name, data):
    path = _file_path(name)
    payload = json.dumps(data, ensure_ascii=False)
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(payload)
    finally:
        handle.close()


def load_favorites():
    data = _read_json(FAV_FILE, {'items': []})
    items = data.get('items') if isinstance(data, dict) else []
    return items if isinstance(items, list) else []


def save_favorites(items):
    _write_json(FAV_FILE, {'items': items})


def fav_key(kind, item_id):
    return f'{kind}:{item_id}'


def is_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    return any(item.get('key') == key for item in load_favorites())


def add_favorite(item):
    items = [entry for entry in load_favorites() if entry.get('key') != item.get('key')]
    items.insert(0, item)
    save_favorites(items)


def remove_favorite(kind, item_id):
    key = fav_key(kind, item_id)
    save_favorites([item for item in load_favorites() if item.get('key') != key])


# --- Progress & Continue Watching ---

def load_progress():
    data = _read_json(PROGRESS_FILE, {})
    return data if isinstance(data, dict) else {}


def get_progress(key):
    return load_progress().get(key)


def set_progress(key, position, total, **meta):
    if not key:
        return
    data = load_progress()
    if total and position >= max(total * 0.92, total - 30):
        data.pop(key, None)
    elif position > 10:
        entry = data.get(key) or {}
        entry.update(meta)
        entry['position'] = float(position)
        entry['total'] = float(total or 0)
        entry['updated'] = time.time()
        data[key] = entry
    else:
        return
    _write_json(PROGRESS_FILE, data)


def remove_progress(key):
    data = load_progress()
    if key in data:
        data.pop(key, None)
        _write_json(PROGRESS_FILE, data)


def clear_progress():
    _write_json(PROGRESS_FILE, {})


def continue_watching():
    items = []
    for key, value in load_progress().items():
        if not isinstance(value, dict):
            continue
        if value.get('position', 0) > 10:
            items.append((key, value))
    items.sort(key=lambda pair: pair[1].get('updated', 0), reverse=True)
    return items[:50]


# --- Watch History Storage ---

def load_history():
    data = _read_json(HISTORY_FILE, {'items': []})
    items = data.get('items') if isinstance(data, dict) else []
    return items if isinstance(items, list) else []


def save_history(items):
    _write_json(HISTORY_FILE, {'items': items[:250]})


def add_history(item):
    if not item or not item.get('key'):
        return
    items = [entry for entry in load_history() if entry.get('key') != item.get('key')]
    items.insert(0, item)
    save_history(items)


def remove_history(key):
    items = [item for item in load_history() if item.get('key') != key]
    save_history(items)


def clear_history(kind=None):
    if not kind or kind == 'all':
        save_history([])
        return
    kinds_to_remove = {
        'movie': {'movie', 'vod'},
        'series': {'series', 'episode'},
        'live': {'live', 'm3u'},
    }.get(kind, {kind})
    items = [item for item in load_history() if item.get('kind') not in kinds_to_remove]
    save_history(items)


def get_history(kind=None):
    items = load_history()
    if not kind or kind == 'all':
        return items
    kinds_to_filter = {
        'movie': {'movie', 'vod'},
        'series': {'series', 'episode'},
        'live': {'live', 'm3u'},
    }.get(kind, {kind})
    return [item for item in items if item.get('kind') in kinds_to_filter]


# --- Fast Compact Search Index ---

def load_search_index(ttl=86400):
    data = _read_json(INDEX_FILE, None)
    if not data or not isinstance(data, dict):
        return None
    if time.time() - data.get('saved', 0) > ttl:
        return None
    # If the index exists but has no shows and no movies, it's incomplete
    if not data.get('shows') and not data.get('movies'):
        return None
    return data


def save_search_index(shows=None, movies=None, live=None):
    existing = _read_json(INDEX_FILE, {}) or {}
    
    def get_any_id(it):
        for k in ('series_id', 'stream_id', 'id', 'vod_id', 'channel_id'):
            v = it.get(k)
            if v is not None and str(v).strip() not in ('', '0'):
                return str(v)
        return None

    def compact_items(items, kind):
        compact = []
        for it in (items or []):
            item_id = get_any_id(it)
            name = it.get('name')
            if not item_id or not name:
                continue
            icon = it.get('cover') or it.get('stream_icon') or it.get('icon') or ''
            entry = {
                'id': item_id,
                'series_id': item_id,
                'stream_id': item_id,
                'name': name,
                'kind': kind,
                'icon': icon,
                'cover': icon,
                'stream_icon': icon,
            }
            if it.get('container_extension'):
                entry['container_extension'] = it.get('container_extension')
                entry['ext'] = it.get('container_extension')
            if it.get('plot'):
                entry['plot'] = it.get('plot')[:300]
            if it.get('rating'):
                entry['rating'] = it.get('rating')
            if it.get('year'):
                entry['year'] = it.get('year')
            compact.append(entry)
        return compact

    if shows is not None and len(shows) > 0:
        existing['shows'] = compact_items(shows, 'series')
    if movies is not None and len(movies) > 0:
        existing['movies'] = compact_items(movies, 'movie')
    if live is not None and len(live) > 0:
        existing['live'] = compact_items(live, 'live')

    existing['saved'] = time.time()
    _write_json(INDEX_FILE, existing)


def clear_search_index():
    path = _file_path(INDEX_FILE)
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


# --- Cache Storage ---

def cache_get(name, ttl=14400):
    path = _file_path(os.path.join(CACHE_DIR, f'{name}.json'))
    if not xbmcvfs.exists(path):
        return None
    try:
        with xbmcvfs.File(path) as handle:
            raw = handle.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        payload = json.loads(raw)
        if ttl is not None and time.time() - payload.get('saved', 0) > ttl:
            return None
        return payload.get('data')
    except Exception:
        return None


def cache_set(name, data):
    folder = _file_path(CACHE_DIR)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    _write_json(os.path.join(CACHE_DIR, f'{name}.json'), {'saved': time.time(), 'data': data})


def clear_cache(prefix=None):
    folder = _file_path(CACHE_DIR)
    if not xbmcvfs.exists(folder):
        return
    try:
        _, files = xbmcvfs.listdir(folder)
        for fname in files:
            if not prefix or fname.startswith(prefix):
                xbmcvfs.delete(os.path.join(folder, fname))
    except Exception as exc:
        xbmc.log(f'[Wandall] clear cache error: {exc}', xbmc.LOGERROR)
